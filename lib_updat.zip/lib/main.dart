import 'package:flutter/material.dart';
import 'package:vms_app/core/routes/app_routes.dart';
import 'package:vms_app/core/service_locator/di.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/core/utils/app_size.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ServiceLocator().init();
  AppSizeService();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    service<AppSizeService>().init(context);
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'VMS Client',
      theme: AppTheme.lightTheme,
      routerConfig: AppRoute.route,
    );
  }
}
