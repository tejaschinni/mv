class ValidationHelper {
  // A robust Regex for email validation
  static const String _emailPattern =
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";

  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }

    final regExp = RegExp(_emailPattern);

    if (!regExp.hasMatch(value)) {
      return 'Please enter a valid email address';
    }

    return null; // Return null if the input is valid
  }
}
