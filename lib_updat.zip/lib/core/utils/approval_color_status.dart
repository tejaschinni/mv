import 'package:flutter/material.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';

Color getStatusColor(AppointmentStatus status) {
  switch (status) {
    case AppointmentStatus.approved:
    case AppointmentStatus.checkedIn:
      return Colors.green;
    case AppointmentStatus.pending:
      return Colors.orange;
    case AppointmentStatus.rejected:
    case AppointmentStatus.cancelled:
      return Colors.red;
    case AppointmentStatus.completed:
    case AppointmentStatus.checkedOut:
      return Colors.blue;
    default:
      return Colors.grey;
  }
}
