import 'package:get_it/get_it.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/core/database/app_database.dart';
import 'package:vms_app/features/auth/data/datasources/auth_local_data_source.dart';
import 'package:vms_app/features/auth/domain/repositories/auth_repository.dart';
import 'package:vms_app/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:vms_app/features/auth/domain/usecases/init_users_usecase.dart';
import 'package:vms_app/features/auth/domain/usecases/login_usecase.dart';

import 'package:vms_app/features/employee/data/datasources/employee_local_data_source.dart';
import 'package:vms_app/features/employee/domain/repositories/employee_repository.dart';
import 'package:vms_app/features/employee/data/repositories/employee_repository_impl.dart';
import 'package:vms_app/features/employee/domain/usecases/get_employees_usecase.dart';
import 'package:vms_app/features/employee/domain/usecases/add_employee_usecase.dart';

import 'package:vms_app/features/appointments/data/datasources/appointment_local_data_source.dart';
import 'package:vms_app/features/appointments/domain/repositories/appointment_repository.dart';
import 'package:vms_app/features/appointments/data/repositories/appointment_repository_impl.dart';
import 'package:vms_app/features/appointments/domain/usecases/get_appointments_usecase.dart';
import 'package:vms_app/features/appointments/domain/usecases/add_appointment_usecase.dart';

final service = GetIt.instance;

class ServiceLocator {
  void init() {
    otherinit();
    authInit();
    employeeInit();
    appointmentInit();
  }

  void otherinit() {
    service.registerLazySingleton<AppSizeService>(() => AppSizeService());
  }

  void authInit() {
    // Database
    service.registerLazySingleton<AppDatabase>(() => AppDatabase.instance);

    // Data source
    service.registerLazySingleton<AuthLocalDataSource>(
      () => AuthLocalDataSourceImpl(appDatabase: service()),
    );

    // Repository
    service.registerLazySingleton<AuthRepository>(
      () => AuthRepositoryImpl(localDataSource: service()),
    );

    // Use cases
    service.registerLazySingleton<InitUsersUseCase>(
      () => InitUsersUseCase(repository: service()),
    );
    service.registerLazySingleton<LoginUseCase>(
      () => LoginUseCase(repository: service()),
    );
  }

  void employeeInit() {
    // Data source
    service.registerLazySingleton<EmployeeLocalDataSource>(
      () => EmployeeLocalDataSourceImpl(appDatabase: service()),
    );

    // Repository
    service.registerLazySingleton<EmployeeRepository>(
      () => EmployeeRepositoryImpl(localDataSource: service()),
    );

    // Use cases
    service.registerLazySingleton<GetEmployeesUseCase>(
      () => GetEmployeesUseCase(repository: service()),
    );
    service.registerLazySingleton<AddEmployeeUseCase>(
      () => AddEmployeeUseCase(repository: service()),
    );
  }

  void appointmentInit() {
    // Data source
    service.registerLazySingleton<AppointmentLocalDataSource>(
      () => AppointmentLocalDataSourceImpl(appDatabase: service()),
    );

    // Repository
    service.registerLazySingleton<AppointmentRepository>(
      () => AppointmentRepositoryImpl(localDataSource: service()),
    );

    // Use cases
    service.registerLazySingleton<GetAppointmentsUseCase>(
      () => GetAppointmentsUseCase(repository: service()),
    );
    service.registerLazySingleton<AddAppointmentUseCase>(
      () => AddAppointmentUseCase(repository: service()),
    );
  }
}
