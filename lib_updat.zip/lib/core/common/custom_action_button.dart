import 'package:flutter/material.dart';

class CustomActionButton extends StatelessWidget {
  const CustomActionButton({
    super.key,
    required this.theme,
    required this.acceptBtnName,
    required this.cancelBtnName,
    required this.onPresseAccept,
    required this.onPressedCancel,
  });
  final String cancelBtnName;
  final String acceptBtnName;
  final void Function()? onPressedCancel;
  final void Function()? onPresseAccept;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () => onPressedCancel,
            style: OutlinedButton.styleFrom(
              foregroundColor: theme.primaryColor,
              side: BorderSide(color: theme.primaryColor, width: 1.5),
              padding: const .symmetric(vertical: 20),
              shape: RoundedRectangleBorder(borderRadius: .circular(16)),
              textStyle: const TextStyle(fontSize: 16, fontWeight: .bold),
            ),
            child: Text(cancelBtnName),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton(
            onPressed: onPresseAccept,
            style: ElevatedButton.styleFrom(
              padding: const .symmetric(vertical: 20),
            ),
            child: Text(acceptBtnName),
          ),
        ),
      ],
    );
  }
}
