import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/routes/app_route_name.dart';
import 'package:vms_app/core/utils/app_size.dart';

class DashboardBottomNavBar extends StatelessWidget {
  final Widget childWidget;
  final int selectedIndex;
  const DashboardBottomNavBar({
    super.key,
    required this.childWidget,
    required this.selectedIndex,
  });

  void _onNavItemTap(BuildContext context, int index) {
    switch (index) {
      case 0:
        context.goNamed(home);
        break;
      case 1:
        context.goNamed(employee);
        break;
      case 2:
        context.goNamed(appointment);
        break;
      case 3:
        context.goNamed(profile);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: childWidget,
      extendBody: true,
      bottomNavigationBar: Container(
        margin: .fromLTRB(
          20,
          0,
          20,
          AppSizes.bottomBarHeight > 0 ? AppSizes.bottomBarHeight : 20,
        ),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: theme.colorScheme.outlineVariant.withAlpha(30),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.shadow.withAlpha(25),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),

        child: ClipRRect(
          borderRadius: .circular(30),
          child: BottomNavigationBar(
            currentIndex: selectedIndex,
            onTap: (index) {
              _onNavItemTap(context, index);
            },
            type: BottomNavigationBarType.fixed,

            elevation: 0,

            backgroundColor: Colors.transparent,
            selectedItemColor: theme.colorScheme.primary,
            unselectedItemColor: theme.colorScheme.onSurfaceVariant,
            selectedLabelStyle: theme.textTheme.labelMedium?.copyWith(
              fontWeight: .w600,
              fontSize: 12,
            ),
            unselectedLabelStyle: theme.textTheme.labelMedium,
            showUnselectedLabels: true,
            items: const [
              BottomNavigationBarItem(
                label: 'Home',
                icon: Icon(Icons.home_filled),
              ),
              BottomNavigationBarItem(
                label: 'Employees',
                icon: Icon(Icons.people_alt_outlined),
              ),
              BottomNavigationBarItem(
                label: 'Appointments',
                icon: Icon(Icons.calendar_month),
              ),
              BottomNavigationBarItem(
                label: 'Profile',
                icon: Icon(Icons.person),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
