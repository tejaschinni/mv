const String splash = 'splash';
const String login = 'login';
const String home = 'home';

// employee
const String employee = 'employee';
const String addEmployee = 'addEmployee';
const String detailEmployee = 'detailEmployee';

const String appointment = 'appointment';
const String appointmentDetail = 'appointmentDetail';
const String appointmentAdd = 'appointmentAdd';

const String profile = 'profile';
