import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/common/dashboar_bottom_nav_bar.dart';
import 'package:vms_app/core/routes/app_route_name.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/screen/appointment_add_screen_2.dart';
import 'package:vms_app/features/appointments/screen/appointment_all_screen.dart';
import 'package:vms_app/features/appointments/screen/appointment_detail_screen.dart';
import 'package:vms_app/features/appointments/screen/apponitment_add_screen.dart';
import 'package:vms_app/features/auth/screens/login_screen.dart';
import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';
import 'package:vms_app/features/employee/screens/add_employee_screen.dart';
import 'package:vms_app/features/employee/screens/employee_detail_screen.dart';
import 'package:vms_app/features/employee/screens/employee_list_screen.dart';
import 'package:vms_app/features/home/screens/home_admin_screen.dart';
import 'package:vms_app/features/profile/screens/profile_screen.dart';
import 'package:vms_app/features/splash/screens/splash_screen.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'rootNavigator',
);

final GlobalKey<NavigatorState> _shellNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'shellNavigator',
);

int _dashboardIndexFromLocation(String location) {
  if (location.startsWith('/dashboard/employee')) return 1;
  if (location.startsWith('/dashboard/appointment')) return 2;
  if (location.startsWith('/dashboard/profile')) return 3;
  return 0;
}

class AppRoute {
  static final GoRouter route = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        name: splash,
        builder: (context, state) => SplashScreen(),
      ),

      GoRoute(
        path: '/login',
        name: login,
        builder: (context, state) => LoginScreen(),
      ),

      ShellRoute(
        builder: (context, state, child) => DashboardBottomNavBar(
          childWidget: child,
          selectedIndex: _dashboardIndexFromLocation(state.uri.path),
        ),
        routes: [
          // all the routes
          GoRoute(
            path: '/dashboard/home',
            name: home,
            builder: (context, state) => const HomeAdminScreen(),
          ),
          GoRoute(
            path: '/dashboard/employee',
            name: employee,
            builder: (context, state) => const EmployeeListScreen(),
            routes: [
              GoRoute(
                path: 'addEmployee',
                name: addEmployee,
                builder: (context, state) => AddEmployeeScreen(),
              ),
              GoRoute(
                path: 'detailEmployee',
                name: detailEmployee,
                builder: (context, state) {
                  final employee = state.extra as Employee;
                  return EmployeeDetailScreen(emp: employee);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/dashboard/appointment',
            name: appointment,
            builder: (context, state) => const AppointmentAllScreen(),
            routes: [
              GoRoute(
                path: 'appointmentAdd',
                name: appointmentAdd,
                builder: (context, state) => AppointmentAddScreen2(),
              ),
              GoRoute(
                path: 'appointmentDetail',
                name: appointmentDetail,
                builder: (context, state) {
                  final appointment = state.extra as AppointmentEntity;
                  return AppointmentDetailScreen(appointment: appointment);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/dashboard/profile',
            name: profile,
            builder: (context, state) => const ProfileScreen(),
          ),
        ],
      ),
    ],
  );
}
