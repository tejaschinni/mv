import 'package:flutter/material.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/core/utils/approval_color_status.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';

class HomeAppointmentCard extends StatelessWidget {
  final AppointmentEntity app;
  const HomeAppointmentCard({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = getStatusColor(app.status);
    return Card(
      margin: const .symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: .circular(16)),
      clipBehavior: .antiAlias,
      child: Row(
        children: [
          Container(width: 6, color: statusColor),
          Padding(
            padding: const .all(8),
            child: SizedBox(
              // height: AppSizes.height(4),
              child: Column(children: [Row(children: [
                     
                    ],
                  )]),
            ),
          ),
        ],
      ),
    );
  }
}
