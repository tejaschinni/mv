import 'package:flutter/material.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/home/screens/widgets/home_appointment_card.dart';

class TodaysTaskWidget extends StatelessWidget {
  final List<AppointmentEntity> list;
  const TodaysTaskWidget({super.key, required this.list});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: .start,
      children: [
        Text("Today's Appointment", style: theme.textTheme.headlineMedium),
        const SizedBox(height: 10),
        SizedBox(
          height: AppSizes.height(20),
          child: ListView.builder(
            padding: .symmetric(horizontal: 20, vertical: 20),
            scrollDirection: .horizontal,
            itemCount: list.length,
            itemBuilder: (context, index) {
              return HomeAppointmentCard(app: list[index]);
            },
          ),
        ),
      ],
    );
  }
}
