import 'package:flutter/material.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/screen/widget/appointment_card_widget.dart';

class HomeAdminScreen extends StatefulWidget {
  const HomeAdminScreen({super.key});

  @override
  State<HomeAdminScreen> createState() => _HomeAdminScreenState();
}

class _HomeAdminScreenState extends State<HomeAdminScreen> {
  final List<AppointmentEntity> appointmentList = [
    AppointmentEntity(
      appointmentId: "APT001",
      visitorName: "John Smith",
      visitorMobile: "9876543210",
      visitorEmail: "john@techcorp.com",
      visitorPhoto: null,
      hostId: "EMP001",
      hostName: "Amit Verma",
      hostDepartment: "IT",
      purpose: "Project Discussion",
      appointmentDate: DateTime.now(),
      startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 9, 30),
      endTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 10, 30),
      locationId: "LOC001",
      locationName: "Tech Corp",
      address: "3rd Floor",
      latitude: 19.1136,
      longitude: 72.8697,
      geofenceRadius: 100,
      status: AppointmentStatus.approved,
      isApproved: true,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR001",
      passCode: "PASS001",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    AppointmentEntity(
      appointmentId: "APT002",
      visitorName: "Sarah Johnson",
      visitorMobile: "9988776655",
      visitorEmail: "sarah@designstudio.com",
      visitorPhoto: null,
      hostId: "EMP002",
      hostName: "Karan Joshi",
      hostDepartment: "HR",
      purpose: "Interview",
      appointmentDate: DateTime.now(),
      startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 10, 0),
      endTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 11, 0),
      locationId: "LOC002",
      locationName: "Design Studio",
      address: "2nd Floor",
      latitude: 19.1197,
      longitude: 72.9050,
      geofenceRadius: 120,
      status: AppointmentStatus.pending,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR002",
      passCode: "PASS002",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    AppointmentEntity(
      appointmentId: "APT003",
      visitorName: "Michael Brown",
      visitorMobile: "9988776655",
      visitorEmail: "michael@finance.com",
      visitorPhoto: null,
      hostId: "EMP003",
      hostName: "Karan Joshi",
      hostDepartment: "Finance",
      purpose: "Meeting",
      appointmentDate: DateTime.now(),
      startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 10, 30),
      endTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 11, 30),
      locationId: "LOC003",
      locationName: "Finance Ltd",
      address: "5th Floor",
      latitude: 19.1197,
      longitude: 72.9050,
      geofenceRadius: 120,
      status: AppointmentStatus.pending,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR003",
      passCode: "PASS003",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
    AppointmentEntity(
      appointmentId: "APT004",
      visitorName: "Emily Davis",
      visitorMobile: "9988776655",
      visitorEmail: "emily@marketing.com",
      visitorPhoto: null,
      hostId: "EMP004",
      hostName: "Karan Joshi",
      hostDepartment: "Marketing",
      purpose: "Meeting",
      appointmentDate: DateTime.now(),
      startTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 11, 0),
      endTime: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day, 12, 0),
      locationId: "LOC004",
      locationName: "Marketing Co",
      address: "4th Floor",
      latitude: 19.1197,
      longitude: 72.9050,
      geofenceRadius: 120,
      status: AppointmentStatus.pending,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR004",
      passCode: "PASS004",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Red Gradient Background Header
          Container(
            height: 280,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFE53935), Color(0xFFC62828), Color(0xFFB71C1C)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(bottom: 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Row: Title and Menu
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Welcome back,",
                              style: theme.textTheme.bodyLarge?.copyWith(
                                color: Colors.white.withOpacity(0.9),
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Admin Dashboard",
                              style: theme.textTheme.displayMedium?.copyWith(
                                color: Colors.white,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.more_vert,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Main Overview Card
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Today's Appointments",
                                    style: theme.textTheme.bodyMedium?.copyWith(
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        "24",
                                        style: theme.textTheme.displayLarge?.copyWith(
                                          fontSize: 48,
                                          fontWeight: FontWeight.bold,
                                          color: const Color(0xFF1F2937),
                                          height: 1,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Padding(
                                        padding: const EdgeInsets.only(bottom: 6),
                                        child: Row(
                                          children: [
                                            const Icon(Icons.arrow_outward, color: Color(0xFF10B981), size: 16),
                                            Text(
                                              "+12%",
                                              style: theme.textTheme.bodyMedium?.copyWith(
                                                color: const Color(0xFF10B981),
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryColor,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: const Icon(
                                  Icons.calendar_month,
                                  color: Colors.white,
                                  size: 32,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _buildSubStat(context, "Active", "8"),
                              _buildSubStat(context, "Completed", "16"),
                              _buildSubStat(context, "Employees", "156"),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Small Stat Cards
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        Expanded(
                          child: _buildSmallStatCard(
                            context,
                            "Active Now",
                            "8",
                            Icons.shield_outlined,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _buildSmallStatCard(
                            context,
                            "Total Staff",
                            "156",
                            Icons.people_alt_outlined,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Upcoming Visits
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Upcoming Visits",
                          style: theme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: const Color(0xFF1F2937),
                          ),
                        ),
                        TextButton(
                          onPressed: () {},
                          child: Text(
                            "View All",
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: AppTheme.primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // List of Appointments
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    padding: EdgeInsets.zero,
                    itemCount: appointmentList.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final appointment = appointmentList[index];
                      return AppointmentCard(
                        appointment: appointment,
                        onTap: () {},
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubStat(BuildContext context, String title, String count) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Colors.grey.shade500,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          count,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildSmallStatCard(BuildContext context, String title, String count, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppTheme.primaryColor.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: AppTheme.primaryColor, size: 24),
          ),
          const SizedBox(height: 16),
          Text(
            count,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: const Color(0xFF1F2937),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }
}
