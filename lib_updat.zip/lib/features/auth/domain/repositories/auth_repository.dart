abstract class AuthRepository {
  Future<void> initMockUsers();
  Future<bool> login(String email, String password);
}
