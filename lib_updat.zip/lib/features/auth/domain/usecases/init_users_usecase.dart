import 'package:vms_app/features/auth/domain/repositories/auth_repository.dart';

class InitUsersUseCase {
  final AuthRepository repository;

  InitUsersUseCase({required this.repository});

  Future<void> call() async {
    await repository.initMockUsers();
  }
}
