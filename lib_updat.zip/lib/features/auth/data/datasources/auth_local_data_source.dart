import 'package:sqflite/sqflite.dart';
import 'package:vms_app/core/database/app_database.dart';

abstract class AuthLocalDataSource {
  Future<void> initMockUsers();
  Future<Map<String, dynamic>?> login(String email, String password);
}

class AuthLocalDataSourceImpl implements AuthLocalDataSource {
  final AppDatabase appDatabase;

  AuthLocalDataSourceImpl({required this.appDatabase});

  @override
  Future<void> initMockUsers() async {
    final db = await appDatabase.database;
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM users'));
    
    if (count == 0) {
      await db.insert('users', {
        'name': 'Admin User',
        'email': 'admin@vms.com',
        'password': 'password123',
        'role': 'Admin'
      });
      await db.insert('users', {
        'name': 'Employee One',
        'email': 'emp1@vms.com',
        'password': 'password123',
        'role': 'Employee'
      });
      await db.insert('users', {
        'name': 'Employee Two',
        'email': 'emp2@vms.com',
        'password': 'password123',
        'role': 'Employee'
      });
    }
  }

  @override
  Future<Map<String, dynamic>?> login(String email, String password) async {
    final db = await appDatabase.database;
    final result = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, password],
    );
    if (result.isNotEmpty) {
      return result.first;
    }
    return null;
  }
}
