import 'package:vms_app/features/auth/domain/repositories/auth_repository.dart';
import 'package:vms_app/features/auth/data/datasources/auth_local_data_source.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthLocalDataSource localDataSource;

  AuthRepositoryImpl({required this.localDataSource});

  @override
  Future<void> initMockUsers() async {
    await localDataSource.initMockUsers();
  }

  @override
  Future<bool> login(String email, String password) async {
    final user = await localDataSource.login(email, password);
    return user != null;
  }
}
