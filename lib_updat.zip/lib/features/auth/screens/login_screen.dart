import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/routes/app_route_name.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/core/service_locator/di.dart';
import 'package:vms_app/features/auth/domain/usecases/init_users_usecase.dart';
import 'package:vms_app/features/auth/domain/usecases/login_usecase.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  bool _isPasswordObsecure = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    service<InitUsersUseCase>().call();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: AppTheme.surfaceColor,
      body: Stack(
        children: [
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.primaryColor.withAlpha(30),
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: .symmetric(
                horizontal: AppSizes.width(5),
                vertical: AppSizes.height(10),
              ),
              child: Column(
                mainAxisSize: .min,
                crossAxisAlignment: .stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 40),
                    child: FlutterLogo(size: 40),
                  ),
                  Text('Sign In', style: theme.textTheme.displayMedium),
                  SizedBox(height: AppSizes.height(1)),
                  Text(
                    'Please enter login details.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  SizedBox(height: AppSizes.height(3)),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email Address',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  SizedBox(height: AppSizes.height(1)),
                  TextFormField(
                    controller: passwordController,
                    obscureText: !_isPasswordObsecure,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isPasswordObsecure
                              ? Icons.visibility_off
                              : Icons.visibility,
                          color: AppTheme.textSecondary,
                        ),
                        onPressed: () {
                          setState(() {
                            _isPasswordObsecure = !_isPasswordObsecure;
                          });
                        },
                      ),
                    ),
                  ),
                  SizedBox(height: AppSizes.height(1.6)),
                  Align(
                    alignment: .centerRight,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        foregroundColor: AppTheme.primaryColor,
                      ),
                      child: const Text('Forgot Password?'),
                    ),
                  ),
                  SizedBox(
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isLoading
                          ? null
                          : () async {
                              setState(() {
                                _isLoading = true;
                              });
                              
                              final email = emailController.text.trim();
                              final password = passwordController.text.trim();
                              final isValidUser = await service<LoginUseCase>().call(email, password);

                              setState(() {
                                _isLoading = false;
                              });
                              
                              if (isValidUser) {
                                if (context.mounted) {
                                  context.goNamed(home);
                                }
                              } else {
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Invalid email or password')),
                                  );
                                }
                              }
                            },
                      child: _isLoading
                          ? SizedBox(
                              height: AppSizes.height(4.4),
                              width: AppSizes.width(4.4),
                              child: CircularProgressIndicator(
                                color: Colors.red,
                                strokeWidth: 2,
                              ),
                            )
                          : const Text('LOGIN'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const _FeatureItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 52,
          width: 52,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(icon, color: Colors.white, size: 26),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(color: Colors.white70, fontSize: 12),
        ),
      ],
    );
  }
}
