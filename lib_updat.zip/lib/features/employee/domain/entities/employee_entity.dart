class Employee {
  final String name;
  final String role;
  final String department;
  final String location;
  final String imageUrl;

  Employee({
    required this.name,
    required this.role,
    required this.department,
    required this.location,
    required this.imageUrl,
  });
}
