import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';

abstract class EmployeeRepository {
  Future<List<Employee>> getEmployees();
  Future<void> addEmployee(Employee employee);
}
