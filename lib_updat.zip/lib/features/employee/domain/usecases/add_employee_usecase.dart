import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';
import 'package:vms_app/features/employee/domain/repositories/employee_repository.dart';

class AddEmployeeUseCase {
  final EmployeeRepository repository;

  AddEmployeeUseCase({required this.repository});

  Future<void> call(Employee employee) async {
    await repository.addEmployee(employee);
  }
}
