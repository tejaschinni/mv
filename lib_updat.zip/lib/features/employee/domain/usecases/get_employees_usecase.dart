import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';
import 'package:vms_app/features/employee/domain/repositories/employee_repository.dart';

class GetEmployeesUseCase {
  final EmployeeRepository repository;

  GetEmployeesUseCase({required this.repository});

  Future<List<Employee>> call() async {
    return await repository.getEmployees();
  }
}
