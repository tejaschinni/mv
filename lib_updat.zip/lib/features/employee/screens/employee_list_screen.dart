import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/common/custom_app_bar.dart';
import 'package:vms_app/core/routes/app_route_name.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';
import 'package:vms_app/features/employee/screens/widgets/employee_card_widget.dart';
import 'package:vms_app/features/employee/screens/widgets/employee_search_bar_widget.dart';

class EmployeeListScreen extends StatefulWidget {
  const EmployeeListScreen({super.key});

  @override
  State<EmployeeListScreen> createState() => _EmployeeListScreenState();
}

class _EmployeeListScreenState extends State<EmployeeListScreen> {
  String selectedCategory = "All";

  final List<String> categories = ["All", "HR", "Manager"];

  final List<Employee> employees = [
    Employee(
      name: 'Sarah Jenkins',
      role: 'HR Specialist',
      department: 'People',
      location: 'Main Campus',
      imageUrl: 'https://i.pravatar.cc/150?u=sarah',
    ),
    Employee(
      name: 'Marcus Chen',
      role: 'HR',
      department: 'Tech',
      location: 'Remote',
      imageUrl: 'https://i.pravatar.cc/150?u=marcus',
    ),
    Employee(
      name: 'Elena Rodriguez',
      role: 'HR',
      department: 'Design',
      location: 'Studio B',
      imageUrl: 'https://i.pravatar.cc/150?u=elena',
    ),
    Employee(
      name: 'David Wilson',
      role: 'Manager',
      department: 'Marketing',
      location: 'Main Campus',
      imageUrl: 'https://i.pravatar.cc/150?u=david',
    ),
    Employee(
      name: 'Jessica Taylor',
      role: 'Support',
      department: 'Support',
      location: 'North Office',
      imageUrl: 'https://i.pravatar.cc/150?u=jessica',
    ),
  ];
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final double bottomPadding =
        30 +
        (AppSizes.bottomBarHeight > 0 ? AppSizes.bottomBarHeight : 20) +
        20;
    return Scaffold(
      backgroundColor: AppTheme.surfaceColor,
      extendBody: true,
      appBar: CustomAppBar(title: 'Employees'),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: AppSizes.height(2)),
          //Search Bar
          EmployeeSearchBarWidget(),

          SizedBox(height: AppSizes.height(4)),

          // Horizontal Filter Chips
          SizedBox(
            height: AppSizes.height(4),
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (context, index) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final category = categories[index];
                return _buildFilterChip(
                  category,
                  isSelected: selectedCategory == category,
                  onTap: () => setState(() => selectedCategory = category),
                );
              },
            ),
          ),

          SizedBox(height: AppSizes.height(2)),

          // Results List
          Expanded(
            child: ListView.builder(
              padding: .only(
                left: 20,
                right: 20,
                top: 10,
                bottom: bottomPadding,
              ),
              itemCount: employees.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                return EmployeeCardWidget(
                  emp: employees[index],
                  onPressFunction: () {
                    context.pushNamed(detailEmployee, extra: employees[index]);
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: Padding(
        padding: .only(bottom: bottomPadding + 30),
        child: FloatingActionButton(
          onPressed: () {
            context.pushNamed(addEmployee);
          },
          backgroundColor: AppTheme.primaryColor,
          child: const Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildFilterChip(
    String label, {
    bool isSelected = false,
    required VoidCallback onTap, // Added callback
  }) {
    return AnimatedContainer(
      // Switched to AnimatedContainer for smooth color transitions
      duration: const Duration(milliseconds: 200),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: .circular(20),
          onTap: onTap, // Making it functional
          child: Container(
            padding: .symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? AppTheme.primaryDark : Colors.white,
              borderRadius: .circular(20),
              border: .all(
                color: isSelected ? AppTheme.primaryDark : Colors.red.shade100,
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black87,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
