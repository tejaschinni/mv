import 'package:flutter/material.dart';
import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';

class EmployeeCardWidget extends StatelessWidget {
  final Employee emp;
  final void Function()? onPressFunction;
  const EmployeeCardWidget({
    super.key,
    required this.emp,
    required this.onPressFunction,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: onPressFunction,
      child: Container(
        margin: .only(bottom: 16),

        padding: .all(12),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: .circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // Profile Image with Border
            Container(
              padding: const .all(2),
              decoration: BoxDecoration(
                shape: .circle,
                border: Border.all(color: Colors.grey.shade100, width: 2),
              ),
              child: CircleAvatar(
                radius: 28,
                child: Icon(Icons.person_2_outlined),
                // backgroundImage: NetworkImage(emp.imageUrl),
              ),
            ),
            const SizedBox(width: 16),
            // Employee Info
            Expanded(
              child: Column(
                crossAxisAlignment: .start,
                children: [
                  Text(
                    emp.name,
                    style: const TextStyle(fontWeight: .bold, fontSize: 16),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    emp.role,
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  // Department Tag
                  Container(
                    padding: .symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: .circular(8),
                    ),
                    child: Text(
                      emp.department,
                      style: TextStyle(
                        color: Colors.blue.shade700,
                        fontSize: 11,
                        fontWeight: .w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Action Button
            const Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16,
              color: Colors.grey,
            ),
          ],
        ),
      ),
    );
  }
}
