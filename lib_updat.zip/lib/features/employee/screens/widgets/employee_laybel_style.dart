import 'package:flutter/material.dart';
import 'package:vms_app/core/theme/app_theme.dart';

TextStyle? labelStyle(BuildContext context) {
  return Theme.of(context).textTheme.bodyMedium?.copyWith(
    color: AppTheme.textPrimary,
    fontWeight: FontWeight.w600,
  );
}
