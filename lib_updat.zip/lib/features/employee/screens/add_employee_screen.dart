import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/common/custom_app_bar.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/employee/screens/widgets/employee_laybel_style.dart';

class AddEmployeeScreen extends StatefulWidget {
  const AddEmployeeScreen({super.key});

  @override
  State<AddEmployeeScreen> createState() => _AddEmployeeScreenState();
}

class _AddEmployeeScreenState extends State<AddEmployeeScreen> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    final double bottomPadding =
        30 +
        (AppSizes.bottomBarHeight > 0 ? AppSizes.bottomBarHeight : 20) +
        20;
    return Scaffold(
      backgroundColor: AppTheme.surfaceColor,
      appBar: CustomAppBar(title: "Add Employee"),
      body: SingleChildScrollView(
        padding: .only(top: 16, left: 16, right: 16, bottom: bottomPadding),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Employee Information',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 24),

                  // Full Name
                  Text('Full Name', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'e.g. Jonathan Aris',
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Job Title
                  Text('Job Title', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'e.g. Senior Operations Manager',
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Department
                  Text('Department', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(hintText: 'Select Role'),
                    items: const [
                      DropdownMenuItem(value: 'hr', child: Text('HR')),
                      DropdownMenuItem(
                        value: 'manager',
                        child: Text('Manager'),
                      ),
                      DropdownMenuItem(
                        value: 'support',
                        child: Text('Support'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  const SizedBox(height: 16),

                  // Office Location
                  Text('Office Location', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      hintText: 'Select Office',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'pune', child: Text('Pune HQ')),
                      DropdownMenuItem(
                        value: 'puune_warehouse',
                        child: Text('Pune Warehouse'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  const SizedBox(height: 32),
                  const Divider(color: Colors.grey),
                  const SizedBox(height: 24),

                  // Contact Details
                  Text(
                    'CONTACT DETAILS',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Work Email', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'j.aris@officehub.com',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Phone Number', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: '+919999999999',
                      prefixIcon: Icon(Icons.phone_outlined),
                    ),
                  ),
                  // const SizedBox(height: 32),

                  // Employee Photo Section
                  // EmployeePhotoPicker(onReplacePhoto: () {}),
                  const SizedBox(height: 48),

                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => context.pop(),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppTheme.primaryColor,
                            side: const BorderSide(
                              color: AppTheme.primaryColor,
                              width: 1.5,
                            ),
                            padding: const .symmetric(vertical: 20),
                            shape: RoundedRectangleBorder(
                              borderRadius: .circular(16),
                            ),
                            textStyle: const TextStyle(
                              fontSize: 16,
                              fontWeight: .bold,
                            ),
                          ),
                          child: const Text('Cancel'),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            padding: const .symmetric(vertical: 20),
                          ),
                          child: const Text('Save Changes'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
