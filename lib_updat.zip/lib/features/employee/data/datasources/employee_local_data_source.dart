import 'package:sqflite/sqflite.dart';
import 'package:vms_app/core/database/app_database.dart';
import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';

abstract class EmployeeLocalDataSource {
  Future<List<Employee>> getEmployees();
  Future<void> addEmployee(Employee employee);
}

class EmployeeLocalDataSourceImpl implements EmployeeLocalDataSource {
  final AppDatabase appDatabase;

  EmployeeLocalDataSourceImpl({required this.appDatabase});

  @override
  Future<List<Employee>> getEmployees() async {
    final db = await appDatabase.database;
    final List<Map<String, dynamic>> maps = await db.query('employees');

    return maps.map((map) {
      return Employee(
        name: map['name'],
        role: map['role'],
        department: map['department'],
        location: map['location'],
        imageUrl: map['imageUrl'],
      );
    }).toList();
  }

  @override
  Future<void> addEmployee(Employee employee) async {
    final db = await appDatabase.database;
    await db.insert(
      'employees',
      {
        'name': employee.name,
        'role': employee.role,
        'department': employee.department,
        'location': employee.location,
        'imageUrl': employee.imageUrl,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
