import 'package:vms_app/features/employee/domain/entities/employee_entity.dart';
import 'package:vms_app/features/employee/domain/repositories/employee_repository.dart';
import 'package:vms_app/features/employee/data/datasources/employee_local_data_source.dart';

class EmployeeRepositoryImpl implements EmployeeRepository {
  final EmployeeLocalDataSource localDataSource;

  EmployeeRepositoryImpl({required this.localDataSource});

  @override
  Future<List<Employee>> getEmployees() async {
    return await localDataSource.getEmployees();
  }

  @override
  Future<void> addEmployee(Employee employee) async {
    await localDataSource.addEmployee(employee);
  }
}
