import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/common/custom_action_button.dart';
import 'package:vms_app/core/common/custom_app_bar.dart';
import 'package:vms_app/core/theme/app_theme.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/employee/screens/widgets/employee_laybel_style.dart';


class AppointmentAddScreen2 extends StatefulWidget {
  const AppointmentAddScreen2({super.key});

  @override
  State<AppointmentAddScreen2> createState() => _AppointmentAddScreen2State();
}

class _AppointmentAddScreen2State extends State<AppointmentAddScreen2> {
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final double bottomPadding =
        30 +
        (AppSizes.bottomBarHeight > 0 ? AppSizes.bottomBarHeight : 20) +
        20;
    return Scaffold(
      backgroundColor: AppTheme.surfaceColor,
      appBar: CustomAppBar(title: "Set Appointment"),
      body: SingleChildScrollView(
        padding: .only(top: 16, left: 16, right: 16, bottom: bottomPadding),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Visitor Information',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 24),

                  // Full Name
                  Text('Full Name', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'e.g. Jonathan Aris',
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Job Title
                  Text('Email', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'e.g abc@mail.in',
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Mobile No.', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'e.g 9999999999',
                    ),
                  ),
                  const SizedBox(height: 16),

                  const SizedBox(height: 32),
                  const Divider(color: Colors.grey),
                  const SizedBox(height: 24),

                  // Meeting detail
                  Text(
                    'Meeting Info',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),

                  const SizedBox(height: 16),
                  Text('Subject', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  TextFormField(
                    decoration: const InputDecoration(
                      hintText: 'Purpose of meeting',
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Select Date', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(hintText: 'Select Date'),
                    items: const [
                      DropdownMenuItem(
                        value: '14-05-2026',
                        child: Text('14-05-2026'),
                      ),
                      DropdownMenuItem(
                        value: '15-05-2026',
                        child: Text('15-05-2026'),
                      ),
                      DropdownMenuItem(
                        value: '16-05-2026',
                        child: Text('16-05-2026'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),

                  const SizedBox(height: 16),
                  // Office Location
                  Text('Slot', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      hintText: 'Select time slot',
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: '11AM-12PM',
                        child: Text('11AM-12PM'),
                      ),
                      DropdownMenuItem(
                        value: '12PM-1PM',
                        child: Text('12M-1PM'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  const SizedBox(height: 32),
                  const Divider(color: Colors.grey),
                  const SizedBox(height: 24),

                  Text(
                    'Location',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 16),

                  Text('Office Location', style: labelStyle(context)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      hintText: 'Select Office',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'pune', child: Text('Pune HQ')),
                      DropdownMenuItem(
                        value: 'warehouse',
                        child: Text('Pune Warehouse'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  const SizedBox(height: 48),

                  //custom Action Buttons
                  CustomActionButton(
                    theme: theme,
                    acceptBtnName: 'Set',
                    cancelBtnName: 'Cancel',
                    onPresseAccept: () {},
                    onPressedCancel: () {},
                  ),
                  SizedBox(height: AppSizes.height(5)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
