import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:vms_app/core/common/custom_app_bar.dart';
import 'package:vms_app/core/routes/app_route_name.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/screen/widget/appointment_card_widget.dart';
import 'package:vms_app/features/employee/screens/widgets/employee_search_bar_widget.dart';
import '../../../core/theme/app_theme.dart';

class AppointmentAllScreen extends StatefulWidget {
  const AppointmentAllScreen({super.key});

  @override
  State<AppointmentAllScreen> createState() => _AppointmentAllScreenState();
}

class _AppointmentAllScreenState extends State<AppointmentAllScreen> {
  String selectedCategory = "All";

  final List<String> categories = ["All", "Pending", "Approved", "Rejected"];

  final List<AppointmentEntity> appointmentList = [
    AppointmentEntity(
      appointmentId: "APT001",
      visitorName: "Rahul Sharma",
      visitorMobile: "9876543210",
      visitorEmail: "rahul@gmail.com",
      visitorPhoto: null,
      hostId: "EMP001",
      hostName: "Amit Verma",
      hostDepartment: "IT",
      purpose: "Project Discussion",
      appointmentDate: DateTime(2026, 5, 13),
      startTime: DateTime(2026, 5, 13, 10, 0),
      endTime: DateTime(2026, 5, 13, 11, 0),
      locationId: "LOC001",
      locationName: "Head Office",
      address: "Andheri East, Mumbai",
      latitude: 19.1136,
      longitude: 72.8697,
      geofenceRadius: 100,
      status: AppointmentStatus.approved,
      isApproved: true,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR001",
      passCode: "PASS001",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),

    AppointmentEntity(
      appointmentId: "APT002",
      visitorName: "Sneha Patil",
      visitorMobile: "9988776655",
      visitorEmail: "sneha@gmail.com",
      visitorPhoto: null,
      hostId: "EMP002",
      hostName: "Karan Joshi",
      hostDepartment: "HR",
      purpose: "Interview",
      appointmentDate: DateTime(2026, 5, 14),
      startTime: DateTime(2026, 5, 14, 12, 0),
      endTime: DateTime(2026, 5, 14, 1, 0),
      locationId: "LOC002",
      locationName: "Corporate Office",
      address: "Powai, Mumbai",
      latitude: 19.1197,
      longitude: 72.9050,
      geofenceRadius: 120,
      status: AppointmentStatus.pending,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR002",
      passCode: "PASS002",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),

    AppointmentEntity(
      appointmentId: "APT003",
      visitorName: "Priya Mehta",
      visitorMobile: "9123456780",
      visitorEmail: "priya@gmail.com",
      visitorPhoto: null,
      hostId: "EMP003",
      hostName: "Rohit Singh",
      hostDepartment: "Finance",
      purpose: "Vendor Meeting",
      appointmentDate: DateTime(2026, 5, 15),
      startTime: DateTime(2026, 5, 15, 2, 0),
      endTime: DateTime(2026, 5, 15, 3, 0),
      locationId: "LOC003",
      locationName: "Finance Branch",
      address: "BKC, Mumbai",
      latitude: 19.0676,
      longitude: 72.8698,
      geofenceRadius: 150,
      status: AppointmentStatus.checkedIn,
      isApproved: true,
      isCheckedIn: true,
      isCheckedOut: false,
      qrCode: "QR003",
      passCode: "PASS003",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),

    AppointmentEntity(
      appointmentId: "APT004",
      visitorName: "Arjun Nair",
      visitorMobile: "9765432109",
      visitorEmail: "arjun@gmail.com",
      visitorPhoto: null,
      hostId: "EMP004",
      hostName: "Neha Kapoor",
      hostDepartment: "Admin",
      purpose: "Office Visit",
      appointmentDate: DateTime(2026, 5, 16),
      startTime: DateTime(2026, 5, 16, 9, 30),
      endTime: DateTime(2026, 5, 16, 10, 30),
      locationId: "LOC004",
      locationName: "Admin Block",
      address: "Thane West, Mumbai",
      latitude: 19.2183,
      longitude: 72.9781,
      geofenceRadius: 100,
      status: AppointmentStatus.completed,
      isApproved: true,
      isCheckedIn: true,
      isCheckedOut: true,
      qrCode: "QR004",
      passCode: "PASS004",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),

    AppointmentEntity(
      appointmentId: "APT005",
      visitorName: "Vikram Desai",
      visitorMobile: "9001122334",
      visitorEmail: "vikram@gmail.com",
      visitorPhoto: null,
      hostId: "EMP005",
      hostName: "Pooja Shah",
      hostDepartment: "Operations",
      purpose: "Maintenance Work",
      appointmentDate: DateTime(2026, 5, 17),
      startTime: DateTime(2026, 5, 17, 4, 0),
      endTime: DateTime(2026, 5, 17, 5, 30),
      locationId: "LOC005",
      locationName: "Operations Center",
      address: "Navi Mumbai",
      latitude: 19.0330,
      longitude: 73.0297,
      geofenceRadius: 200,
      status: AppointmentStatus.rejected,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR005",
      passCode: "PASS005",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),

    AppointmentEntity(
      appointmentId: "APT006",
      visitorName: "Anjali Kulkarni",
      visitorMobile: "9887766554",
      visitorEmail: "anjali@gmail.com",
      visitorPhoto: null,
      hostId: "EMP006",
      hostName: "Suresh Yadav",
      hostDepartment: "Sales",
      purpose: "Client Presentation",
      appointmentDate: DateTime(2026, 5, 18),
      startTime: DateTime(2026, 5, 18, 11, 0),
      endTime: DateTime(2026, 5, 18, 12, 30),
      locationId: "LOC006",
      locationName: "Sales Office",
      address: "Lower Parel, Mumbai",
      latitude: 18.9988,
      longitude: 72.8306,
      geofenceRadius: 130,
      status: AppointmentStatus.cancelled,
      isApproved: false,
      isCheckedIn: false,
      isCheckedOut: false,
      qrCode: "QR006",
      passCode: "PASS006",
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    final double bottomPadding =
        40 +
        (AppSizes.bottomBarHeight > 0 ? AppSizes.bottomBarHeight : 20) +
        40;
    return Scaffold(
      backgroundColor: AppTheme.surfaceColor,
      appBar: CustomAppBar(title: "Appointments"),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: AppSizes.height(2)),
          //Search Bar
          EmployeeSearchBarWidget(),

          SizedBox(height: AppSizes.height(4)),

          SizedBox(
            height: AppSizes.height(4),
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              separatorBuilder: (context, index) => const SizedBox(width: 10),
              itemBuilder: (context, index) {
                final category = categories[index];
                return _buildFilterChip(
                  category,
                  isSelected: selectedCategory == category,
                  onTap: () => setState(() => selectedCategory = category),
                );
              },
            ),
          ),

          SizedBox(height: AppSizes.height(2)),

          Expanded(
            child: ListView.builder(
              padding: .only(
                left: 20,
                right: 20,
                top: 10,
                bottom: bottomPadding,
              ),
              itemCount: appointmentList.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                return AppointmentCard(
                  appointment: appointmentList[index],
                  onTap: () {
                    context.pushNamed(
                      appointmentDetail,
                      extra: appointmentList[index],
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: Padding(
        padding: .only(bottom: bottomPadding + 30),
        child: FloatingActionButton(
          onPressed: () {
            context.pushNamed(appointmentAdd);
          },
          backgroundColor: AppTheme.primaryColor,
          child: const Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildFilterChip(
    String label, {
    bool isSelected = false,
    required VoidCallback onTap, // Added callback
  }) {
    return AnimatedContainer(
      // Switched to AnimatedContainer for smooth color transitions
      duration: const Duration(milliseconds: 200),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: .circular(20),
          onTap: onTap, // Making it functional
          child: Container(
            padding: .symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? AppTheme.primaryDark : Colors.white,
              borderRadius: .circular(20),
              border: .all(
                color: isSelected ? AppTheme.primaryDark : Colors.red.shade100,
              ),
            ),
            child: Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.black87,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
