import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:vms_app/core/utils/app_size.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/core/common/custom_action_button.dart';

class AppointmentDetailScreen extends StatelessWidget {
  final AppointmentEntity appointment;

  const AppointmentDetailScreen({super.key, required this.appointment});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          _buildAppBar(context, theme),
          SliverToBoxAdapter(
            child: Padding(
              padding: const .all(20),
              child: Column(
                crossAxisAlignment: .start,
                children: [
                  _buildStatusHeader(theme, appointment.status),
                  SizedBox(height: AppSizes.height(1.2)),
                  _buildSectionTitle(theme, "Appointment Details"),
                  _buildDetailTile(
                    theme,
                    icon: Icons.event,
                    label: "Date",
                    value: DateFormat(
                      'EEEE, d MMMM yyyy',
                    ).format(appointment.appointmentDate),
                  ),
                  _buildDetailTile(
                    theme,
                    icon: Icons.access_time,
                    label: "Time Slot",
                    value:
                        "${DateFormat('hh:mm a').format(appointment.startTime)} - ${DateFormat('hh:mm a').format(appointment.endTime)}",
                  ),
                  _buildDetailTile(
                    theme,
                    icon: Icons.question_answer_outlined,
                    label: "Purpose of Visit",
                    value: appointment.purpose,
                  ),
                  Divider(height: AppSizes.height(2)),
                  _buildSectionTitle(theme, "Host Information"),
                  _buildContactCard(
                    theme,
                    title: appointment.hostName,
                    subtitle:
                        appointment.hostDepartment ?? "No Department Assigned",
                    icon: Icons.person_pin_circle_outlined,
                  ),
                  const SizedBox(height: 24),
                  _buildSectionTitle(theme, "Location"),
                  _buildLocationCard(theme),

                  const SizedBox(height: 24),
                  CustomActionButton(
                    theme: theme,
                    acceptBtnName: "Check-in",
                    cancelBtnName: "Cancel",
                    onPresseAccept: () {},
                    onPressedCancel: () {},
                  ),
                  SizedBox(height: AppSizes.height(21.5)),
                  // Space for bottom buttons
                ],
              ),
            ),
          ),
        ],
      ),
      // bottomSheet: _buildActionButtons(theme),
    );
  }

  Widget _buildAppBar(BuildContext context, ThemeData theme) {
    return SliverAppBar(
      expandedHeight: AppSizes.height(25),
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        centerTitle: true,
        title: Text(
          appointment.visitorName,
          textAlign: .center,
          style: TextStyle(color: theme.colorScheme.onPrimaryContainer),
        ),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: .topCenter,
              end: .bottomCenter,
              colors: [
                theme.colorScheme.primaryContainer,
                theme.colorScheme.surface,
              ],
            ),
          ),
          child: Center(
            child: CircleAvatar(
              radius: 50,
              backgroundColor: theme.colorScheme.primary,
              child: Text(
                appointment.visitorName[0],
                style: theme.textTheme.headlineLarge?.copyWith(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusHeader(ThemeData theme, AppointmentStatus status) {
    return Container(
      padding: const .all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.secondaryContainer.withAlpha(128),
        borderRadius: .circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, color: theme.colorScheme.primary),
          const SizedBox(width: 12),
          Text(
            "Current Status:",
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          Text(
            status.name.toUpperCase(),
            textAlign: .center,
            style: theme.textTheme.labelLarge?.copyWith(
              color: theme.colorScheme.primary,
              fontWeight: .bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(ThemeData theme, String title) {
    return Padding(
      padding: const .only(bottom: 12.0),
      child: Text(
        title,
        style: theme.textTheme.titleMedium?.copyWith(
          color: theme.colorScheme.primary,
          fontWeight: .bold,
        ),
      ),
    );
  }

  Widget _buildDetailTile(
    ThemeData theme, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Padding(
      padding: const .symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.outline),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: .start,
            children: [
              Text(label, style: theme.textTheme.labelSmall),
              Text(value, style: theme.textTheme.bodyLarge),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContactCard(
    ThemeData theme, {
    required String title,
    required String subtitle,
    required IconData icon,
  }) {
    return Card(
      elevation: 0,
      color: theme.colorScheme.onSurfaceVariant.withAlpha(50),
      child: ListTile(
        leading: Icon(icon, color: theme.colorScheme.primary),
        title: Text(title, style: const TextStyle(fontWeight: .bold)),
        subtitle: Text(subtitle),
        trailing: IconButton(
          icon: const Icon(Icons.message_outlined),
          onPressed: () {},
        ),
      ),
    );
  }

  Widget _buildLocationCard(ThemeData theme) {
    return Column(
      children: [
        ListTile(
          contentPadding: .zero,
          leading: const Icon(Icons.map_outlined),
          title: Text(appointment.locationName),
          subtitle: Text(appointment.address),
        ),
        // Placeholder for a Map View
        // Container(
        //   height: 150,
        //   width: double.infinity,
        //   decoration: BoxDecoration(
        //     color: theme.colorScheme.onSurfaceVariant,
        //     borderRadius: .circular(12),
        //   ),
        //   child: const Center(
        //     child: Icon(Icons.map_rounded, size: 40, color: Colors.grey),
        //   ),
        // ),
      ],
    );
  }
}
