import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:vms_app/core/common/custom_app_bar.dart';
import 'package:vms_app/core/utils/app_size.dart';

class ApponitmentAddScreen extends StatefulWidget {
  const ApponitmentAddScreen({super.key});

  @override
  State<ApponitmentAddScreen> createState() => _ApponitmentAddScreenState();
}

class _ApponitmentAddScreenState extends State<ApponitmentAddScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _visitorNameController = TextEditingController();
  final TextEditingController _purposeController = TextEditingController();

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _startTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _endTime = const TimeOfDay(hour: 10, minute: 0);

  // Helper to pick Date
  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
    );
    if (picked != null) setState(() => _selectedDate = picked);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: CustomAppBar(title: 'Schedule Appointment'),
      body: SingleChildScrollView(
        padding: .all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: .start,
            children: [
              Text(
                "Visitor Information",
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.primaryColor,
                ),
              ),
              SizedBox(height: AppSizes.height(2)),

              TextFormField(
                controller: _visitorNameController,
                decoration: const InputDecoration(
                  labelText: 'Visitor Name',
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Enter visitor name' : null,
              ),

              const SizedBox(height: 20),
              Text(
                "Schedule Details",
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.primaryColor,
                ),
              ),
              const SizedBox(height: 12),

              // Date Picker Tile
              ListTile(
                tileColor: theme.colorScheme.onSurfaceVariant.withAlpha(77),
                shape: RoundedRectangleBorder(borderRadius: .circular(8)),
                leading: const Icon(Icons.calendar_today),
                title: const Text("Appointment Date"),
                subtitle: Text(DateFormat('yyyy-MM-dd').format(_selectedDate)),
                onTap: _pickDate,
              ),

              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {}, // Add TimePicker logic
                      icon: const Icon(Icons.access_time),
                      label: Text("Start: ${_startTime.format(context)}"),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {}, // Add TimePicker logic
                      icon: const Icon(Icons.update),
                      label: Text("End: ${_endTime.format(context)}"),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),
              TextFormField(
                controller: _purposeController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Purpose of Visit',
                  alignLabelWithHint: true,
                ),
              ),

              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                height: AppSizes.height(7),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: theme.primaryColor,
                    foregroundColor: theme.colorScheme.onPrimary,
                    shape: RoundedRectangleBorder(borderRadius: .circular(8)),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      // Logic to map to AppointmentEntity
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Processing Appointment...'),
                        ),
                      );
                    }
                  },
                  child: const Text(
                    'CREATE APPOINTMENT',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
