import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/domain/repositories/appointment_repository.dart';

class GetAppointmentsUseCase {
  final AppointmentRepository repository;

  GetAppointmentsUseCase({required this.repository});

  Future<List<AppointmentEntity>> call() async {
    return await repository.getAppointments();
  }
}
