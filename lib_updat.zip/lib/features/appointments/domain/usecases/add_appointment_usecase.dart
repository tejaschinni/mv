import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/domain/repositories/appointment_repository.dart';

class AddAppointmentUseCase {
  final AppointmentRepository repository;

  AddAppointmentUseCase({required this.repository});

  Future<void> call(AppointmentEntity appointment) async {
    await repository.addAppointment(appointment);
  }
}
