class AppointmentEntity {
  final String appointmentId;

  // Visitor Details
  final String visitorName;
  final String visitorMobile;
  final String? visitorEmail;
  final String? visitorPhoto;

  // Host Details
  final String hostId;
  final String hostName;
  final String? hostDepartment;

  // Appointment Details
  final String purpose;
  final DateTime appointmentDate;
  final DateTime startTime;
  final DateTime endTime;

  // Location Details
  final String locationId;
  final String locationName;
  final String address;
  final double latitude;
  final double longitude;
  final double geofenceRadius;

  // Status
  final AppointmentStatus status;

  // Approval / Check-in
  final bool isApproved;
  final bool isCheckedIn;
  final bool isCheckedOut;

  // QR / Pass
  final String? qrCode;
  final String? passCode;

  // Metadata
  final DateTime createdAt;
  final DateTime updatedAt;

  AppointmentEntity({
    required this.appointmentId,
    required this.visitorName,
    required this.visitorMobile,
    this.visitorEmail,
    this.visitorPhoto,
    required this.hostId,
    required this.hostName,
    this.hostDepartment,
    required this.purpose,
    required this.appointmentDate,
    required this.startTime,
    required this.endTime,
    required this.locationId,
    required this.locationName,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.geofenceRadius,
    required this.status,
    required this.isApproved,
    required this.isCheckedIn,
    required this.isCheckedOut,
    this.qrCode,
    this.passCode,
    required this.createdAt,
    required this.updatedAt,
  });

  AppointmentEntity copyWith({
    String? appointmentId,
    String? visitorName,
    String? visitorMobile,
    String? visitorEmail,
    String? visitorPhoto,
    String? hostId,
    String? hostName,
    String? hostDepartment,
    String? purpose,
    DateTime? appointmentDate,
    DateTime? startTime,
    DateTime? endTime,
    String? locationId,
    String? locationName,
    String? address,
    double? latitude,
    double? longitude,
    double? geofenceRadius,
    AppointmentStatus? status,
    bool? isApproved,
    bool? isCheckedIn,
    bool? isCheckedOut,
    String? qrCode,
    String? passCode,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AppointmentEntity(
      appointmentId: appointmentId ?? this.appointmentId,
      visitorName: visitorName ?? this.visitorName,
      visitorMobile: visitorMobile ?? this.visitorMobile,
      visitorEmail: visitorEmail ?? this.visitorEmail,
      visitorPhoto: visitorPhoto ?? this.visitorPhoto,
      hostId: hostId ?? this.hostId,
      hostName: hostName ?? this.hostName,
      hostDepartment: hostDepartment ?? this.hostDepartment,
      purpose: purpose ?? this.purpose,
      appointmentDate: appointmentDate ?? this.appointmentDate,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      locationId: locationId ?? this.locationId,
      locationName: locationName ?? this.locationName,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      geofenceRadius: geofenceRadius ?? this.geofenceRadius,
      status: status ?? this.status,
      isApproved: isApproved ?? this.isApproved,
      isCheckedIn: isCheckedIn ?? this.isCheckedIn,
      isCheckedOut: isCheckedOut ?? this.isCheckedOut,
      qrCode: qrCode ?? this.qrCode,
      passCode: passCode ?? this.passCode,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

enum AppointmentStatus {
  pending,
  approved,
  rejected,
  cancelled,
  completed,
  checkedIn,
  checkedOut,
}
