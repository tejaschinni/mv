import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';

abstract class AppointmentRepository {
  Future<List<AppointmentEntity>> getAppointments();
  Future<void> addAppointment(AppointmentEntity appointment);
}
