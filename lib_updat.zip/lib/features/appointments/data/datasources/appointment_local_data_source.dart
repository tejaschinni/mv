import 'package:sqflite/sqflite.dart';
import 'package:vms_app/core/database/app_database.dart';
import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';

abstract class AppointmentLocalDataSource {
  Future<List<AppointmentEntity>> getAppointments();
  Future<void> addAppointment(AppointmentEntity appointment);
}

class AppointmentLocalDataSourceImpl implements AppointmentLocalDataSource {
  final AppDatabase appDatabase;

  AppointmentLocalDataSourceImpl({required this.appDatabase});

  @override
  Future<List<AppointmentEntity>> getAppointments() async {
    final db = await appDatabase.database;
    final List<Map<String, dynamic>> maps = await db.query('appointments');

    return maps.map((map) {
      return AppointmentEntity(
        appointmentId: map['appointmentId'],
        visitorName: map['visitorName'],
        visitorMobile: map['visitorMobile'],
        visitorEmail: map['visitorEmail'],
        visitorPhoto: map['visitorPhoto'],
        hostId: map['hostId'],
        hostName: map['hostName'],
        hostDepartment: map['hostDepartment'],
        purpose: map['purpose'],
        appointmentDate: DateTime.parse(map['appointmentDate']),
        startTime: DateTime.parse(map['startTime']),
        endTime: DateTime.parse(map['endTime']),
        locationId: map['locationId'],
        locationName: map['locationName'],
        address: map['address'],
        latitude: map['latitude'],
        longitude: map['longitude'],
        geofenceRadius: map['geofenceRadius'],
        status: AppointmentStatus.values.firstWhere((e) => e.name == map['status']),
        isApproved: map['isApproved'] == 1,
        isCheckedIn: map['isCheckedIn'] == 1,
        isCheckedOut: map['isCheckedOut'] == 1,
        qrCode: map['qrCode'],
        passCode: map['passCode'],
        createdAt: DateTime.parse(map['createdAt']),
        updatedAt: DateTime.parse(map['updatedAt']),
      );
    }).toList();
  }

  @override
  Future<void> addAppointment(AppointmentEntity appointment) async {
    final db = await appDatabase.database;
    await db.insert(
      'appointments',
      {
        'appointmentId': appointment.appointmentId,
        'visitorName': appointment.visitorName,
        'visitorMobile': appointment.visitorMobile,
        'visitorEmail': appointment.visitorEmail,
        'visitorPhoto': appointment.visitorPhoto,
        'hostId': appointment.hostId,
        'hostName': appointment.hostName,
        'hostDepartment': appointment.hostDepartment,
        'purpose': appointment.purpose,
        'appointmentDate': appointment.appointmentDate.toIso8601String(),
        'startTime': appointment.startTime.toIso8601String(),
        'endTime': appointment.endTime.toIso8601String(),
        'locationId': appointment.locationId,
        'locationName': appointment.locationName,
        'address': appointment.address,
        'latitude': appointment.latitude,
        'longitude': appointment.longitude,
        'geofenceRadius': appointment.geofenceRadius,
        'status': appointment.status.name,
        'isApproved': appointment.isApproved ? 1 : 0,
        'isCheckedIn': appointment.isCheckedIn ? 1 : 0,
        'isCheckedOut': appointment.isCheckedOut ? 1 : 0,
        'qrCode': appointment.qrCode,
        'passCode': appointment.passCode,
        'createdAt': appointment.createdAt.toIso8601String(),
        'updatedAt': appointment.updatedAt.toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
