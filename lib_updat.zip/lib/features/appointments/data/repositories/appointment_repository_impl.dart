import 'package:vms_app/features/appointments/domain/entities/appointment_entity.dart';
import 'package:vms_app/features/appointments/domain/repositories/appointment_repository.dart';
import 'package:vms_app/features/appointments/data/datasources/appointment_local_data_source.dart';

class AppointmentRepositoryImpl implements AppointmentRepository {
  final AppointmentLocalDataSource localDataSource;

  AppointmentRepositoryImpl({required this.localDataSource});

  @override
  Future<List<AppointmentEntity>> getAppointments() async {
    return await localDataSource.getAppointments();
  }

  @override
  Future<void> addAppointment(AppointmentEntity appointment) async {
    await localDataSource.addAppointment(appointment);
  }
}
